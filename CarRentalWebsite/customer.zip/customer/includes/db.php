<?php 

$con = mysqli_connect("wyvern.cs.newpaltz.edu","b_f19_15","7l5v7w","b_f19_15_db");

?>